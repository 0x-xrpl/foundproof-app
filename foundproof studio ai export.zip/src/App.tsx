/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Signal, Wifi, BatteryFull, ChevronLeft, Camera, MapPin, Clock, CheckCircle2, User, History, ShieldCheck, X, FileText, ArrowRight, Building2, Map, Search } from 'lucide-react';
import { IllLogo, IllFind, IllHandoff, IllWallet, IllCamera, IllScan, IllProof, IllBlockchain, IllMap } from './components/Illustrations';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

type Screen =
  | 'splash' | 'onboarding1' | 'onboarding2' | 'wallet_connect' | 'wallet_connected'
  | 'home' | 'start_recording' | 'camera' | 'ai_scan' | 'record_form' | 'location_confirm'
  | 'handoff_selection' | 'pre_anchor_review' | 'writing_progress' | 'proof_summary'
  | 'proof_detail' | 'map' | 'history' | 'history_detail' | 'profile' | 'handoff_facility';

const TEAL = '#64CCC5';
const DARK = '#172B2A';

// Dummy history data (removed static array)

const ScreenWrapper = ({ children, hideNav = false, onBack, onGoHome, noScroll = false }: { children: React.ReactNode, hideNav?: boolean, onBack?: () => void, onGoHome?: () => void, noScroll?: boolean, key?: string }) => (
  <motion.div
    initial={{ opacity: 0, x: 20 }}
    animate={{ opacity: 1, x: 0 }}
    exit={{ opacity: 0, x: -20 }}
    transition={{ duration: 0.15, ease: 'easeOut' }}
    className="absolute inset-0 bg-[#FAFAFA] flex flex-col"
  >
    {/* iOS Status Bar */}
    <div className="h-12 w-full flex items-center justify-between px-6 pt-2 shrink-0 z-50 bg-transparent">
      <span className="text-[15px] font-semibold text-[#172B2A]">9:41</span>
      <div className="flex items-center gap-1.5">
        <Signal className="w-4 h-4 text-[#172B2A]" />
        <Wifi className="w-4 h-4 text-[#172B2A]" />
        <div className="flex items-center gap-1">
          <span className="text-[11px] font-bold text-[#172B2A]">82%</span>
          <BatteryFull className="w-[22px] h-[22px] text-[#172B2A]" />
        </div>
      </div>
    </div>

    {/* Optional Top Nav */}
    {!hideNav && onBack && (
      <div className="h-12 w-full flex items-center px-4 shrink-0">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-gray-100 transition-colors">
          <ChevronLeft className="w-6 h-6 text-[#172B2A]" />
        </button>
      </div>
    )}

    {/* Content */}
    <div className={`flex-1 relative flex flex-col ${noScroll ? 'overflow-hidden' : 'overflow-y-auto pb-8'}`}>
      {children}
    </div>

    {/* Home Indicator */}
    <div className="h-8 w-full flex items-center justify-center shrink-0 bg-transparent pb-2 cursor-pointer" onClick={onGoHome}>
      <div className="w-1/3 h-1.5 bg-[#172B2A]/20 rounded-full hover:bg-[#172B2A]/40 transition-colors" />
    </div>
  </motion.div>
);

const Button = ({ children, onClick, variant = 'primary', className = '', disabled = false }: any) => {
  const baseStyle = "w-full py-4 rounded-full font-bold text-lg transition-transform flex items-center justify-center gap-2";
  const variants = {
    primary: disabled ? "bg-gray-300 text-gray-500 cursor-not-allowed" : "bg-[#64CCC5] text-[#172B2A] active:scale-95 hover:bg-[#85E0D6] transition-colors",
    secondary: disabled ? "bg-gray-100 text-gray-400 border-2 border-gray-200 cursor-not-allowed" : "bg-white text-[#172B2A] border border-gray-200 shadow-sm active:scale-95 hover:bg-gray-50 hover:shadow-md transition-all",
    text: disabled ? "bg-transparent text-gray-300 cursor-not-allowed" : "bg-transparent text-[#718096] hover:text-[#172B2A] active:scale-95 transition-colors",
  };
  return (
    <button onClick={disabled ? undefined : onClick} disabled={disabled} className={`${baseStyle} ${variants[variant as keyof typeof variants]} ${className}`}>
      {children}
    </button>
  );
};

export default function App() {
  const [screen, setScreen] = useState<Screen>('splash');
  const [walletConnected, setWalletConnected] = useState(false);
  const [historyData, setHistoryData] = useState<any[]>([
    {
      id: 1,
      category: '黒い傘',
      time: '2026/03/10 18:45',
      location: '渋谷駅 ハチ公口付近',
      handoff: '交番（渋谷駅前交番）',
      memo: '持ち手が少し欠けています。',
      hash: '0x1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b',
      lat: 35.6590,
      lng: 139.7000,
    },
    {
      id: 2,
      category: '定期入れ',
      time: '2026/03/12 09:15',
      location: '新宿駅 東口改札付近',
      handoff: '駅窓口（新宿駅）',
      memo: '茶色の革製で、Suicaが入っていました。',
      hash: '0x9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f',
      lat: 35.6900,
      lng: 139.7005,
    }
  ]);
  const [selectedHistoryId, setSelectedHistoryId] = useState<number | null>(null);
  const [isCameraHovered, setIsCameraHovered] = useState(false);
  const [recordData, setRecordData] = useState({
    category: '',
    memo: '',
    time: '',
    location: '',
    handoffCategory: '',
    handoffFacility: '',
  });

  // Derived handoff string
  const handoffString = recordData.handoffFacility 
    ? `${recordData.handoffCategory}（${recordData.handoffFacility}）`
    : recordData.handoffCategory;

  // Auto-transition for splash
  useEffect(() => {
    if (screen === 'splash') {
      const timer = setTimeout(() => setScreen('onboarding1'), 2000);
      return () => clearTimeout(timer);
    }
    if (screen === 'ai_scan') {
      const timer = setTimeout(() => {
        setRecordData({
          category: 'ワイヤレスイヤホン',
          memo: '黒色のケースに入っていました。',
          time: '2026/03/15 10:30',
          location: '東京都渋谷区道玄坂2丁目',
          handoffCategory: '',
          handoffFacility: '',
        });
        setScreen('record_form');
      }, 2500);
      return () => clearTimeout(timer);
    }
    if (screen === 'writing_progress') {
      const timer = setTimeout(() => {
        const newRecord = {
          id: Date.now(),
          category: recordData.category,
          time: recordData.time,
          location: recordData.location,
          handoff: recordData.handoffFacility ? `${recordData.handoffCategory}（${recordData.handoffFacility}）` : recordData.handoffCategory,
          memo: recordData.memo,
          hash: '0x' + Math.random().toString(16).slice(2) + '...3b4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d',
          lat: 35.6580 + (Math.random() - 0.5) * 0.01,
          lng: 139.6980 + (Math.random() - 0.5) * 0.01,
        };
        setHistoryData(prev => [newRecord, ...prev]);
        setSelectedHistoryId(newRecord.id);
        setScreen('proof_summary');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [screen, recordData]);

  const handleGoHome = () => {
    if (screen === 'home') {
      setScreen('splash');
    } else {
      setScreen('home');
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-200 p-4 font-sans text-[#172B2A]">
      <div className="w-full max-w-[390px] h-[844px] bg-black rounded-[40px] shadow-2xl overflow-hidden relative ring-1 ring-black/5 p-2">
        <div className="w-full h-full bg-[#FAFAFA] rounded-[32px] overflow-hidden relative">
          <AnimatePresence mode="wait">
            
            {/* 1. Splash */}
            {screen === 'splash' && (
              <motion.div 
                key="splash"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-[#172B2A] flex flex-col items-center justify-center z-50 cursor-pointer"
                onClick={() => setScreen('onboarding1')}
              >
                <div className="w-24 h-24 bg-[#64CCC5] rounded-3xl flex items-center justify-center mb-6 shadow-lg">
                  <Search className="w-12 h-12 text-white" />
                </div>
                <h1 className="text-4xl font-bold text-white tracking-wider mb-2">FoundProof</h1>
                <p className="text-[#64CCC5] font-medium tracking-widest text-sm">落とし物証明アプリ</p>
              </motion.div>
            )}

            {/* 2. Onboarding 1 */}
            {screen === 'onboarding1' && (
              <ScreenWrapper key="ob1" hideNav onGoHome={handleGoHome}>
              <div className="flex-1 flex flex-col p-8">
                <div className="flex-1 flex flex-col items-center justify-center">
                  <IllFind className="w-64 h-64 mb-12" />
                  <h2 className="text-2xl font-bold mb-4 text-center leading-tight">記録する</h2>
                  <p className="text-[#718096] text-center leading-relaxed">
                    見つけた場所や時間を安全に記録し、<br/>あなたの責任ある行動を証明します。
                  </p>
                </div>
                <div className="flex flex-col items-center gap-6 mt-auto">
                  <div className="flex gap-2">
                    <div className="w-2 h-2 rounded-full bg-[#172B2A]" />
                    <div className="w-2 h-2 rounded-full bg-gray-300" />
                  </div>
                  <Button onClick={() => setScreen('onboarding2')}>次へ</Button>
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 3. Onboarding 2 */}
          {screen === 'onboarding2' && (
            <ScreenWrapper key="ob2" onBack={() => setScreen('onboarding1')} onGoHome={handleGoHome}>
              <div className="flex-1 flex flex-col p-8">
                <div className="flex-1 flex flex-col items-center justify-center">
                  <IllHandoff className="w-64 h-64 mb-12" />
                  <h2 className="text-2xl font-bold mb-4 text-center leading-tight">届ける</h2>
                  <p className="text-[#718096] text-center leading-relaxed">
                    交番や施設の窓口へ届けたことを記録し、<br/>ブロックチェーンに証跡として残します。
                  </p>
                </div>
                <div className="flex flex-col items-center gap-6 mt-auto">
                  <div className="flex gap-2">
                    <div className="w-2 h-2 rounded-full bg-gray-300" />
                    <div className="w-2 h-2 rounded-full bg-[#172B2A]" />
                  </div>
                  <Button onClick={() => setScreen('wallet_connect')}>はじめる</Button>
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 4. Wallet Connect */}
          {screen === 'wallet_connect' && (
            <ScreenWrapper key="wallet" onBack={() => setScreen('onboarding2')} onGoHome={handleGoHome}>
              <div className="flex-1 flex flex-col p-8">
                <div className="flex-1 flex flex-col items-center justify-center">
                  <IllWallet className="w-64 h-64 mb-12" />
                  <h2 className="text-2xl font-bold mb-4 text-center">ウォレットを接続</h2>
                  <p className="text-[#718096] text-center leading-relaxed">
                    記録をあなた自身の証明として残すために、<br/>ウォレットを接続してください。
                  </p>
                </div>
                <div className="flex flex-col gap-4 mt-auto">
                  <Button onClick={() => { setWalletConnected(true); setScreen('wallet_connected'); }}>ウォレットを接続</Button>
                  <Button variant="text" onClick={() => setScreen('home')}>あとで設定</Button>
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 5. Wallet Connected */}
          {screen === 'wallet_connected' && (
            <ScreenWrapper key="wallet_done" hideNav onGoHome={handleGoHome}>
              <div className="flex-1 flex flex-col p-8 items-center justify-center">
                <div className="w-24 h-24 bg-[#E0F7F4] rounded-full flex items-center justify-center mb-8">
                  <CheckCircle2 className="w-12 h-12 text-[#64CCC5]" />
                </div>
                <h2 className="text-2xl font-bold mb-4 text-center">接続完了</h2>
                <p className="text-[#718096] text-center leading-relaxed mb-12">
                  ウォレットの接続が完了しました。<br/>記録を始めましょう。
                </p>
                <Button onClick={() => setScreen('home')}>次へ進む</Button>
              </div>
            </ScreenWrapper>
          )}

          {/* 6. Home */}
          {screen === 'home' && (
            <ScreenWrapper key="home" hideNav onGoHome={handleGoHome}>
              <div className="p-6 flex flex-col h-full">
                <div className="flex justify-between items-center mb-8">
                  <h1 className="text-2xl font-bold">FoundProof</h1>
                  <button onClick={() => setScreen('profile')} className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm">
                    <User className="w-5 h-5 text-[#172B2A]" />
                  </button>
                </div>

                <div className="flex-1 flex flex-col gap-6">
                  {/* Primary Action */}
                  <button 
                    onClick={() => setScreen('start_recording')}
                    className="w-full bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col items-center justify-center gap-4 active:scale-95 transition-all duration-300 hover:bg-[#E0F7F4]/30 hover:shadow-md"
                  >
                    <div className="w-16 h-16 bg-[#E0F7F4] rounded-full flex items-center justify-center">
                      <Camera className="w-8 h-8 text-[#64CCC5]" />
                    </div>
                    <span className="text-xl font-bold">見つけたものを記録する</span>
                  </button>

                  {/* Secondary Actions */}
                  <div className="grid grid-cols-2 gap-4">
                    <button onClick={() => setScreen('history')} className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col items-center justify-center gap-3 active:scale-95 transition-all duration-300 min-h-[140px] hover:bg-[#E0F7F4]/30 hover:shadow-md">
                      <History className="w-8 h-8 text-[#172B2A]" />
                      <span className="font-bold text-sm">過去の記録</span>
                    </button>
                    <button onClick={() => setScreen('map')} className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col items-center justify-center gap-3 active:scale-95 transition-all duration-300 min-h-[140px] hover:bg-[#E0F7F4]/30 hover:shadow-md">
                      <Map className="w-8 h-8 text-[#172B2A]" />
                      <span className="font-bold text-sm">発見マップ</span>
                    </button>
                  </div>
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 7. Start Recording */}
          {screen === 'start_recording' && (
            <ScreenWrapper key="start_rec" onBack={() => setScreen('home')} onGoHome={handleGoHome}>
              <div className="flex-1 flex flex-col p-8">
                <div className="flex-1 flex flex-col items-center justify-center">
                  <IllCamera className="w-64 h-64 mb-12" />
                  <h2 className="text-2xl font-bold mb-4 text-center">記録を始める</h2>
                  <p className="text-[#718096] text-center leading-relaxed">
                    見つけた落とし物の写真を撮って、<br/>AIに情報を読み取らせましょう。
                  </p>
                </div>
                <div className="mt-auto">
                  <Button onClick={() => setScreen('camera')}>
                    <Camera className="w-5 h-5" /> 写真を撮る
                  </Button>
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 8. Camera View */}
          {screen === 'camera' && (
            <motion.div 
              initial={{ opacity: 0, y: '100%' }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              drag="y"
              dragConstraints={{ top: 0, bottom: 0 }}
              dragElastic={0.2}
              onDragEnd={(e, { offset, velocity }) => {
                if (offset.y > 100 || velocity.y > 500) {
                  setScreen('start_recording');
                }
              }}
              className="absolute inset-0 bg-black flex flex-col z-50 rounded-[40px] overflow-hidden"
            >
              <div className="p-4 flex justify-between items-center z-10 mt-12">
                <button onClick={() => setScreen('start_recording')} className="p-2">
                  <X className="w-8 h-8 text-white" />
                </button>
              </div>
              <div className="flex-1 relative overflow-hidden flex items-center justify-center">
                {/* Fake Camera Preview */}
                <div className="absolute inset-0 bg-gray-800" />
                <div className={`w-64 h-64 border-2 rounded-3xl flex items-center justify-center relative z-10 transition-colors duration-300 ${isCameraHovered ? 'border-[#64CCC5]' : 'border-white/50'}`}>
                  {isCameraHovered && (
                    <motion.div 
                      initial={{ scale: 1.2, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ duration: 0.3, ease: "easeOut" }}
                      className="absolute inset-0 border-2 border-[#64CCC5] rounded-3xl"
                    />
                  )}
                  <div className="w-32 h-24 bg-gray-700/80 rounded-2xl rotate-12 shadow-2xl flex flex-col items-center justify-center border border-gray-600 relative overflow-hidden">
                    {/* Earphone case lid line */}
                    <div className="absolute top-1/3 left-0 right-0 h-px bg-gray-600 w-full" />
                    {/* Indicator light */}
                    <div className="absolute top-1/2 mt-2 w-1.5 h-1.5 bg-green-400 rounded-full" />
                  </div>
                </div>
              </div>
              <div className="h-40 bg-[#172B2A] flex items-center justify-center pb-8 relative border-t border-gray-800">
                 <div className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-1.5 bg-gray-600 rounded-full mt-2" />
                <button 
                  onClick={() => {
                    setIsCameraHovered(false);
                    setScreen('ai_scan');
                  }}
                  onMouseEnter={() => setIsCameraHovered(true)}
                  onMouseLeave={() => setIsCameraHovered(false)}
                  className="w-20 h-20 rounded-full border-4 border-[#64CCC5] flex items-center justify-center active:scale-95 transition-transform hover:scale-105"
                >
                  <div className={`w-16 h-16 rounded-full transition-colors ${isCameraHovered ? 'bg-[#85E0D6]' : 'bg-[#64CCC5]'}`} />
                </button>
              </div>
            </motion.div>
          )}

          {/* 9. AI Scan */}
          {screen === 'ai_scan' && (
            <ScreenWrapper key="scan" hideNav onGoHome={handleGoHome}>
              <div className="flex-1 flex flex-col items-center justify-center p-8 bg-[#172B2A]">
                <div className="relative w-64 h-64 mb-12">
                  <IllScan className="w-full h-full" />
                  <motion.div 
                    animate={{ top: ['25%', '75%', '25%'] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                    className="absolute left-[25%] right-[25%] h-1 bg-[#64CCC5] shadow-[0_0_15px_#64CCC5]"
                  />
                </div>
                <h2 className="text-2xl font-bold mb-4 text-white">AIで解析中...</h2>
                <p className="text-white/70 text-center leading-relaxed">
                  写真から落とし物の情報を<br/>読み取っています。
                </p>
              </div>
            </ScreenWrapper>
          )}

          {/* 10. Record Form */}
          {screen === 'record_form' && (
            <ScreenWrapper key="form" onBack={() => setScreen('camera')} onGoHome={handleGoHome}>
              <div className="p-6 flex flex-col h-full">
                <h2 className="text-2xl font-bold mb-6">記録の確認</h2>
                <div className="flex-1 flex flex-col gap-6">
                  <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
                    <label className="text-sm font-bold text-[#718096] mb-2 block">カテゴリー</label>
                    <input 
                      type="text" 
                      value={recordData.category} 
                      onChange={e => setRecordData({...recordData, category: e.target.value})}
                      className="w-full text-lg font-bold bg-transparent outline-none" 
                    />
                  </div>
                  <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
                    <label className="text-sm font-bold text-[#718096] mb-2 block">見つけた時間</label>
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-[#64CCC5]" />
                      <input 
                        type="text" 
                        value={recordData.time} 
                        onChange={e => setRecordData({...recordData, time: e.target.value})}
                        className="w-full text-lg font-bold bg-transparent outline-none" 
                      />
                    </div>
                  </div>
                  <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
                    <label className="text-sm font-bold text-[#718096] mb-2 block">補足メモ</label>
                    <textarea 
                      value={recordData.memo} 
                      onChange={e => setRecordData({...recordData, memo: e.target.value})}
                      className="w-full text-base bg-transparent outline-none resize-none h-20" 
                    />
                  </div>
                </div>
                <div className="mt-6">
                  <Button onClick={() => setScreen('location_confirm')}>次へ</Button>
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 11. Location Confirm */}
          {screen === 'location_confirm' && (
            <ScreenWrapper key="location" onBack={() => setScreen('record_form')} onGoHome={handleGoHome}>
              <div className="p-6 flex flex-col h-full">
                <h2 className="text-2xl font-bold mb-6">場所の確認</h2>
                <div className="flex-1 flex flex-col items-center justify-center">
                  <IllMap className="w-64 h-64 mb-12" />
                  <div className="bg-white/90 backdrop-blur-sm px-6 py-3 rounded-full shadow-sm border border-gray-100 text-center">
                    <p className="text-sm font-bold text-[#64CCC5]">GPSで取得しました</p>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 mt-auto mb-6">
                  <label className="text-sm font-bold text-[#718096] mb-2 block">場所の修正・追記（任意）</label>
                  <input 
                    type="text" 
                    value={recordData.location} 
                    onChange={e => setRecordData({...recordData, location: e.target.value})}
                    className="w-full text-lg font-bold bg-transparent outline-none" 
                    placeholder="例：〇〇ビルの前"
                  />
                </div>
                <div className="mt-auto">
                  <Button onClick={() => setScreen('handoff_selection')}>次へ</Button>
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 12. Handoff Selection */}
          {screen === 'handoff_selection' && (
            <ScreenWrapper key="handoff" onBack={() => setScreen('location_confirm')} onGoHome={handleGoHome}>
              <div className="p-6 flex flex-col h-full">
                <h2 className="text-2xl font-bold mb-6">どこへ届けますか？</h2>
                <div className="flex-1 flex flex-col gap-3">
                  {['交番・警察署', '駅の窓口', '商業施設の受付', '学校・オフィスの窓口', 'その他'].map((option) => (
                    <button 
                      key={option}
                      onClick={() => {
                        setRecordData({...recordData, handoffCategory: option});
                      }}
                      className={`p-5 rounded-2xl text-left font-bold text-lg transition-colors border ${recordData.handoffCategory === option ? 'bg-[#E0F7F4] border-[#64CCC5]/30 text-[#172B2A] ring-2 ring-[#64CCC5]/20' : 'bg-white border-gray-100 text-[#172B2A]'}`}
                    >
                      {option}
                    </button>
                  ))}
                </div>
                <div className="mt-6">
                  <Button disabled={!recordData.handoffCategory} onClick={() => setScreen('handoff_facility')}>次へ</Button>
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 12.5 Handoff Facility Input */}
          {screen === 'handoff_facility' && (
            <ScreenWrapper key="handoff_facility" onBack={() => setScreen('handoff_selection')} onGoHome={handleGoHome}>
              <div className="p-6 flex flex-col h-full">
                <h2 className="text-2xl font-bold mb-2">具体的な施設名</h2>
                <p className="text-[#718096] mb-6">より確実な証明のために、施設名を入力してください。（任意）</p>
                
                <div className="flex-1 flex flex-col gap-6">
                  <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
                    <label className="text-sm font-bold text-[#718096] mb-2 block">届け先</label>
                    <div className="text-lg font-bold mb-4">{recordData.handoffCategory}</div>
                    
                    <label className="text-sm font-bold text-[#718096] mb-2 block">施設名</label>
                    <input 
                      type="text" 
                      placeholder="例：渋谷駅前交番"
                      value={recordData.handoffFacility} 
                      onChange={e => setRecordData({...recordData, handoffFacility: e.target.value})}
                      className="w-full text-lg font-bold bg-transparent outline-none" 
                      autoFocus
                    />
                  </div>
                </div>
                <div className="mt-6">
                  <Button onClick={() => setScreen('pre_anchor_review')}>確認へ進む</Button>
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 13. Pre-Anchor Review */}
          {screen === 'pre_anchor_review' && (
            <ScreenWrapper key="review" onBack={() => setScreen('handoff_selection')} onGoHome={handleGoHome}>
              <div className="p-6 flex flex-col h-full">
                <h2 className="text-2xl font-bold mb-6">記録の最終確認</h2>
                <div className="flex-1 overflow-y-auto">
                  <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col gap-6">
                    <div>
                      <span className="text-sm font-bold text-[#718096] block mb-1">カテゴリー</span>
                      <span className="text-lg font-bold">{recordData.category}</span>
                    </div>
                    <div>
                      <span className="text-sm font-bold text-[#718096] block mb-1">時間</span>
                      <span className="text-lg font-bold">{recordData.time}</span>
                    </div>
                    <div>
                      <span className="text-sm font-bold text-[#718096] block mb-1">場所</span>
                      <span className="text-lg font-bold">{recordData.location}</span>
                    </div>
                    <div>
                      <span className="text-sm font-bold text-[#718096] block mb-1">届け先</span>
                      <span className="text-lg font-bold">{handoffString}</span>
                    </div>
                    <div>
                      <span className="text-sm font-bold text-[#718096] block mb-1">メモ</span>
                      <span className="text-base font-bold">{recordData.memo}</span>
                    </div>
                  </div>
                </div>
                <div className="mt-6 pt-4">
                  <p className="text-sm text-center text-[#718096] mb-4 font-bold">この内容でブロックチェーンに記録します</p>
                  <Button onClick={() => setScreen('writing_progress')}>記録を確定する</Button>
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 14. Writing Progress */}
          {screen === 'writing_progress' && (
            <ScreenWrapper key="writing" hideNav onGoHome={handleGoHome}>
              <div className="flex-1 flex flex-col items-center justify-center p-8">
                <IllBlockchain className="w-64 h-64 mb-12 animate-pulse" />
                <h2 className="text-2xl font-bold mb-4 text-center">記録を書き込み中...</h2>
                <p className="text-[#718096] text-center leading-relaxed">
                  改ざんされない証明として、<br/>ブロックチェーンに記録しています。
                </p>
              </div>
            </ScreenWrapper>
          )}

          {/* 15. Proof Summary */}
          {screen === 'proof_summary' && (
            <ScreenWrapper key="summary" hideNav onGoHome={handleGoHome}>
              <div className="flex-1 flex flex-col p-8 items-center justify-center">
                <IllProof className="w-64 h-64 mb-12" />
                <h2 className="text-2xl font-bold mb-2 text-center">証明が作成されました</h2>
                <p className="text-[#64CCC5] font-mono text-sm mb-8 bg-[#E0F7F4] px-4 py-2 rounded-full">ID: FP-8A2B9C</p>
                <p className="text-[#718096] text-center leading-relaxed mb-12">
                  あなたの責任ある行動が、<br/>確かな記録として残りました。
                </p>
                <div className="w-full flex flex-col gap-4">
                  <Button onClick={() => setScreen('proof_detail')}>証明の詳細を見る</Button>
                  <Button variant="text" onClick={() => setScreen('home')}>ホームへ戻る</Button>
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 16. Proof Detail */}
          {screen === 'proof_detail' && (
            <ScreenWrapper key="detail" onBack={() => setScreen('proof_summary')} onGoHome={handleGoHome}>
              <div className="p-6 flex flex-col h-full">
                <h2 className="text-2xl font-bold mb-6">証明の詳細</h2>
                {(() => {
                  const item = historyData.find(h => h.id === selectedHistoryId) || historyData[0];
                  if (!item) return null;
                  return (
                    <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col gap-6">
                      <div className="flex items-center gap-3 pb-4 border-b border-gray-100">
                        <ShieldCheck className="w-8 h-8 text-[#64CCC5]" />
                        <div>
                          <p className="font-bold">Verified on Symbol</p>
                          <p className="text-xs text-[#718096]">{item.time}</p>
                        </div>
                      </div>
                      <div>
                        <span className="text-sm font-bold text-[#718096] block mb-1">Transaction Hash</span>
                        <p className="font-mono text-xs break-all bg-gray-50 p-3 rounded-xl">
                          {item.hash}
                        </p>
                      </div>
                      <div>
                        <span className="text-sm font-bold text-[#718096] block mb-1">Record Data</span>
                        <div className="bg-gray-50 p-4 rounded-xl text-sm space-y-2">
                          <p><span className="font-bold">Category:</span> {item.category}</p>
                          <p><span className="font-bold">Location:</span> {item.location}</p>
                          <p><span className="font-bold">Handoff:</span> {item.handoff}</p>
                        </div>
                      </div>
                    </div>
                  );
                })()}
                <div className="mt-auto pt-6">
                  <Button variant="secondary" onClick={() => {}}>Explorerで確認</Button>
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 17. Map View */}
          {screen === 'map' && (
            <ScreenWrapper key="map_view" hideNav onGoHome={handleGoHome} noScroll>
              <div className="flex flex-col h-full">
                <div className="h-12 w-full flex items-center px-4 shrink-0 bg-white z-10">
                  <button onClick={() => setScreen('home')} className="p-2 rounded-full hover:bg-gray-100 transition-colors">
                    <ChevronLeft className="w-6 h-6 text-[#172B2A]" />
                  </button>
                  <h2 className="text-lg font-bold ml-2">発見マップ</h2>
                </div>
                <div className="flex-1 relative bg-[#E0F7F4] z-0">
                  <MapContainer center={[35.6700, 139.7100]} zoom={13} style={{ width: '100%', height: '100%' }} zoomControl={false}>
                    <TileLayer
                      attribution='&copy; <a href="https://carto.com/attributions">CARTO</a>'
                      url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
                    />
                    {historyData.map((item) => (
                      <Marker 
                        key={item.id} 
                        position={[item.lat, item.lng]} 
                        icon={new L.DivIcon({
                          className: 'custom-leaflet-icon',
                          html: `<div style="width: 36px; height: 36px; background-color: white; border: 2px solid #64CCC5; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 6px rgba(0,0,0,0.1);"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#64CCC5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg></div>`,
                          iconSize: [36, 36],
                          iconAnchor: [18, 36],
                        })}
                        eventHandlers={{
                          click: () => {
                            setSelectedHistoryId(item.id);
                            setScreen('history_detail');
                          },
                        }}
                      />
                    ))}
                  </MapContainer>
                  
                  {/* Bottom Sheet */}
                  <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl p-6 shadow-[0_-10px_40px_rgba(0,0,0,0.05)] z-[1000]">
                    <div className="w-12 h-1.5 bg-[#172B2A]/20 rounded-full mx-auto mb-6" />
                    <h3 className="font-bold text-lg mb-4">最近の記録</h3>
                    {historyData.length === 0 ? (
                      <p className="text-[#718096] text-center py-4">まだ記録がありません</p>
                    ) : (
                      <div className="flex flex-col gap-3 max-h-48 overflow-y-auto pr-3 pb-2 custom-scrollbar">
                        {historyData.map(item => (
                          <div key={item.id} onClick={() => { setSelectedHistoryId(item.id); setScreen('history_detail'); }} className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl active:scale-95 transition-all duration-300 cursor-pointer hover:bg-[#E0F7F4]/50 hover:shadow-sm shrink-0">
                            <div className="w-12 h-12 bg-[#E0F7F4] rounded-full flex items-center justify-center shrink-0">
                              <FileText className="w-6 h-6 text-[#64CCC5]" />
                            </div>
                            <div className="flex-1">
                              <p className="font-bold">{item.category}</p>
                              <p className="text-sm text-[#718096]">{item.handoff}へお届け</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 18. History List */}
          {screen === 'history' && (
            <ScreenWrapper key="history" onBack={() => setScreen('home')} onGoHome={handleGoHome}>
              <div className="p-6 flex flex-col h-full">
                <h2 className="text-2xl font-bold mb-6">過去の記録</h2>
                {historyData.length === 0 ? (
                  <div className="flex-1 flex flex-col items-center justify-center text-center">
                    <History className="w-16 h-16 text-gray-300 mb-4" />
                    <p className="text-[#718096] font-bold">まだ記録がありません</p>
                  </div>
                ) : (
                  <div className="flex flex-col gap-4">
                    {historyData.map((item) => (
                      <button 
                        key={item.id}
                        onClick={() => {
                          setSelectedHistoryId(item.id);
                          setScreen('history_detail');
                        }}
                        className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4 text-left active:scale-95 transition-all duration-300 hover:bg-[#E0F7F4]/30 hover:shadow-md"
                      >
                        <div className="w-12 h-12 bg-[#E0F7F4] rounded-full flex items-center justify-center shrink-0">
                          <FileText className="w-6 h-6 text-[#64CCC5]" />
                        </div>
                        <div className="flex-1">
                          <p className="font-bold">{item.category}</p>
                          <p className="text-sm text-[#718096]">{item.time.split(' ')[0]}</p>
                        </div>
                        <ShieldCheck className="w-5 h-5 text-[#64CCC5]" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </ScreenWrapper>
          )}

          {/* 19. History Detail */}
          {screen === 'history_detail' && (
            <ScreenWrapper key="history_detail" onBack={() => setScreen('history')} onGoHome={handleGoHome}>
              <div className="flex flex-col h-full overflow-hidden">
                <div className="p-6 pb-2 shrink-0">
                  <h2 className="text-2xl font-bold">記録の詳細</h2>
                </div>
                <div className="flex-1 overflow-y-auto p-6 pt-2">
                  {(() => {
                    const item = historyData.find(h => h.id === selectedHistoryId) || historyData[0];
                    if (!item) return null;
                    return (
                      <div className="bg-white rounded-3xl overflow-hidden shadow-sm border border-gray-100 flex flex-col mb-8 shrink-0">
                        <div className="p-6 flex flex-col gap-6">
                          <div className="flex items-center justify-between border-b border-gray-100 pb-4">
                            <span className="font-bold text-lg">{item.category}</span>
                            <span className="bg-[#E0F7F4] text-[#64CCC5] px-3 py-1 rounded-full text-xs font-bold">Proof Verified</span>
                          </div>
                          <div>
                            <span className="text-sm font-bold text-[#718096] block mb-1">時間</span>
                            <span className="text-base font-bold">{item.time}</span>
                          </div>
                          <div>
                            <span className="text-sm font-bold text-[#718096] block mb-1">場所</span>
                            <span className="text-base font-bold">{item.location}</span>
                          </div>
                          <div>
                            <span className="text-sm font-bold text-[#718096] block mb-1">届け先</span>
                            <span className="text-base font-bold">{item.handoff}</span>
                          </div>
                          <div>
                            <span className="text-sm font-bold text-[#718096] block mb-1">メモ</span>
                            <span className="text-base font-bold">{item.memo}</span>
                          </div>
                          <div className="flex flex-col gap-3 mt-8 pb-6">
                            <Button variant="secondary" onClick={() => setScreen('map')}>
                              マップで見る
                            </Button>
                            <Button variant="secondary" onClick={() => setScreen('proof_detail')}>
                              証明データを確認
                            </Button>
                          </div>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>
            </ScreenWrapper>
          )}

          {/* 20. Profile */}
          {screen === 'profile' && (
            <ScreenWrapper key="profile" onBack={() => setScreen('home')} onGoHome={handleGoHome}>
              <div className="p-6 flex flex-col h-full">
                <h2 className="text-2xl font-bold mb-8">プロフィール</h2>
                
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex items-center gap-4 mb-8 transition-all duration-300 hover:bg-[#E0F7F4]/30 hover:shadow-md cursor-pointer">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                    <User className="w-8 h-8 text-[#718096]" />
                  </div>
                  <div>
                    <p className="font-bold text-lg">ゲストユーザー</p>
                    <p className="text-sm text-[#718096]">記録数: {historyData.length}件</p>
                  </div>
                </div>

                <div className="flex flex-col gap-4">
                  <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 flex items-center justify-between transition-all duration-300 hover:bg-[#E0F7F4]/30 hover:shadow-md cursor-pointer">
                    <div className="flex items-center gap-3">
                      <Building2 className="w-6 h-6 text-[#172B2A]" />
                      <span className="font-bold">ウォレット接続</span>
                    </div>
                    {walletConnected ? (
                      <div className="flex flex-col items-end">
                        <span className="text-sm font-bold text-[#64CCC5] bg-[#E0F7F4] px-3 py-1 rounded-full mb-1">接続済み</span>
                        <span className="text-xs font-mono text-gray-500">0x8f2a...3c4d</span>
                      </div>
                    ) : (
                      <button onClick={() => setScreen('wallet_connect')} className="text-sm font-bold text-white bg-[#172B2A] px-4 py-2 rounded-full">
                        接続する
                      </button>
                    )}
                  </div>
                  
                  <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 flex items-center justify-between text-left transition-all duration-300 hover:bg-[#E0F7F4]/30 hover:shadow-md cursor-pointer">
                    <div className="flex items-center gap-3">
                      <ShieldCheck className="w-6 h-6 text-[#172B2A]" />
                      <span className="font-bold">セキュリティ設定</span>
                    </div>
                    <span className="text-sm font-bold text-green-600 bg-green-50 px-3 py-1 rounded-full">安全</span>
                  </div>
                </div>
              </div>
            </ScreenWrapper>
          )}

        </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

